landingpage checklist
1, create all the files i need
  + 'index.html'
  + "ninjas.html"
  + "dojo.html"
  + "app.js"
2,  write the html for my static pages
3,  build the node server
  + 'require' my dependencies:
    + 'fs'
    + 'http'
  + create and the server
  + fiure out wich file the http request is looking for
  + read and send the file to the browser {if the file/url doesnt exist, send a '404' with a **file not found!!** message}
